// requisição do módulo de conexão do express
const app = require('./config/server');

// requisição da rota da página home e inicialização do módulo passando a variável app
const home = require('./app/routes/homeRoute');
home(app);

// requisição do módulo de upload e inicialização passando a variável app
const upload = require('./app/routes/uploadRoute')
upload(app)

// requisiçao do módulo do Twitter e inicialização
const twitter = require('./app/routes/twitterRoute')
twitter();

// requisição do módulo de análise de texto do NLU e inicialização
const nlu = require('./app/routes/nluRoute')
nlu();