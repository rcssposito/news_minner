// criação da função para exportar toda a chamada como função 
function nluCall() {
    // request
    const nlu = require('../../config/nlu')
    // para o futuro, precisa receber aqui a variável content da rota upload
    var text = 'Daytona International Speedway is getting a facelift — and for the grand dame of superspeedways, it’s time. Track president Joie Chitwood believes that “the World Center of Racing” which holds NASCAR’s annual kick-off party with the Daytona 500 needs to “live up to the expectation that the fan has when they attend the Super Bowl” of stock car racing.'
    
    // definição dos parâmetros a serem usado, podemos usar limit, mentions, model, sentiment, emotion
    // limit é int e model um txt, o resto é boolean
    const params = {
        'text': text,
        'features': {
            'entities': {
                'model': 'f4658cb6-1bc9-4722-83de-a17708e0b4d2',
                'mentions': true,
                'limit': 2
            }
        }
    };

    // chamada com resposta em json
    nlu.analyze(params)
        .then(analysisResults => {
            console.log(JSON.stringify(analysisResults, null, 2));
        })
        .catch(err => {
            console.log('error:', err);
        });
}

module.exports = nluCall