// exportar usando o servidor do express através do parâmetro app
module.exports = function (app) {

  // chamada do módulo do object storage
  const s3 = require('../../config/objectStorage');

  //inicio do upload

  // módulo multer e multers3 gerenciam os arquivos para upload
  const multer = require('multer')
  const multerS3 = require('multer-s3')

  // variável setando o nome do bucket
  const bucket = 'future-club'

  // As duas variáveis devem ser var, a ideia é acessá-las globalmente
  // var para receber o nome do arquivo
  var fileBuffer;
  // var para receber o texto do buffer
  var content;

  // variável para configurar o destino do arquivo
  const upload = multer({
    // definição do local de armazenamento
    storage: multerS3({
      // referência a credencial de API
      s3: s3,
      // precisa explicar?
      bucket: bucket,
      metadata: function (req, file, cb) {
        cb(null, {
          fieldName: file.originalname
        });
      },
      // o arquivo que será passado. O nome é salvo como data + nome original para evitar sobrescrição
      key: function (req, file, cb) {
        cb(null, new Date().toISOString() + file.originalname)
      }
    })
  })


  // envio do arquivo através do submit feito no front
  // variável upload é enviada como middleware para definir para onde o arquivo vai
  app.post('/', upload.single('file'), function (req, res, next) {

    // recebe o nome da key
    fileBuffer = req.file.key

    // função para buscar no object storage o arquivo que acabamos de mandar
    function getItem() {

      console.log(`Retrieving from bucket: ${bucket}, key: ${fileBuffer}`);

      // chamada de get, PRECISA passar o bucket e a key (nome do arquivo)
      return s3.getObject({
          Bucket: bucket,
          Key: fileBuffer
        }).promise()
        // se o conteúdo não for vazio, converter o buffer em texto
        .then((data) => {
          if (data != null) {
            content = Buffer.from(data.Body).toString()
            res.send(content);
          }
        })
        .catch((e) => {
          console.error(`ERROR: ${e.code} - ${e.message}\n`);
        });
    }
    // chamada da função passando o bucket e a key como parâmetro
    getItem(bucket, fileBuffer);
    console.log('Successfully uploaded ')
  })
}