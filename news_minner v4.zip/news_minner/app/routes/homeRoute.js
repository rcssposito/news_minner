//passar a rota do módulo de chamada da página home como função 
module.exports = function (app) {
    // método de chamada da página home
    app.get('/', function (req, res) {
        // renderização da página para exibição
        res.render("home");
    });
};