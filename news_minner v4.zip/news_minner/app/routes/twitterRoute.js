// lib para usar módulos do Twitter
var twitter = require('twitter');
// importar as credenciais
var config = require('../../config/twitter')

// setar uma variável com a configuração para usar como início do método de chamada
var t = new twitter(config);

// variável global para receber os tweets em json
var tContent;

// definição dos parâmetros que devem ser passados na busca da api
var params = {
  q: 'Trump', //substituir esse set manual por uma variável com valor enviado por um input
  count: 1,
  result_type: 'recent',
  lang: 'en'
}

// função criada para exportar como módulo
function tweets() {
  // chamada padrão segundo a documentação do Twitter
  t.get('search/tweets', params, function (err, data, res) {
    tContent = data; //passar o json do tweet para um variável, se comporta como array
    // console.log(tContent);
  })
}

module.exports = tweets