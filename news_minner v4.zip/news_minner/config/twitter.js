// exportar as credencias de acesso
module.exports = {
    consumer_key: '8rGdLrg9IuDB15Loj6C5X4wm0',
    consumer_secret: 'rmNLY3OVP307xXyCzAW0xF7Nma6aFo60rUIVrTBGhTLmIkEmdV',
    access_token_key: '1196472915602149376-74oiqd8v7s2jOQnuW8mMMZiTHObhqe',
    access_token_secret: 'IwFBet8fn0JAgNzlpbO9YyEqqZzALW37oFpCKANwNuxAt'
}