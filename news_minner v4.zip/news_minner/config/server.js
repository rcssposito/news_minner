// importação das libs obrigatórias para executar o app 
const express = require('express');
const app = express();

//direcionar o tipo de arquivo que o express deve buscar ao executar 
app.set('view engine', 'ejs');
//define o caminho da pasta 'views', neste caso, './app/views'
app.set('views', './app/views');

//Criar o acesso da porta 3000 para executar o app
// define a variável para receber a porta de acesso
const port = process.env.PORT || 3000;

//função de escuta para verificar se o servidor funciona
app.listen(port, function () {
    //criação de mensagem no terminal para notificar em qual porta a aplicação esta rodando
    console.log("Running on: http://localhost:" + port)
});

// exportação do servidor express
module.exports = app;