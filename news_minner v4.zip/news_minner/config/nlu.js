// importação da lib do NLU
const naturalLanguageUnderstanding = require('ibm-watson/natural-language-understanding/v1');

// não sei pra que serve além do óbvio do nome
const { IamAuthenticator } = require('ibm-watson/auth');

// setando os dados das credenciais do NLU
const nlu = new naturalLanguageUnderstanding({
  version: '2019-07-12',
  authenticator: new IamAuthenticator({
    apikey: 'NIRJTfjag-kr7LN1aIjgv0DCVujIemGrRCkV0builBQA',
  }),
  url: 'https://gateway.watsonplatform.net/natural-language-understanding/api',
});

module.exports = nlu