// importação da biblioteca definida na documentação da API do Object Storage 
const objectStore = require('ibm-cos-sdk');

// variável de configuração com as credenciais da API
const config = {
    // endpoint do BUCKET, pegar o público 
    endpoint: 's3.us-south.cloud-object-storage.appdomain.cloud',
    // accesskey do HMAC da credencial com permissão de manager
    // a ideia de usar o manager é que assim você consegue escrever e ler no bucket/depósito
    accessKeyId: '571d4898cccb45b5a70b936a4d7791b5',
    // secret do HMAC, mesmo que a anterior
    secretAccessKey: '5311c4a7079187393f4c1b1d354056f767d18c6d5f652178',
    // região onde seu bucket está hospedado
    region: 'us-south'
};

// variável unindo o módulo e a configuração da API
const cos = new objectStore.S3(config);

// exportação da variável cos para fazer upload em outros módulos
module.exports = cos